from abc import ABC, abstractmethod

class BaseAgent(ABC):

    def __init__(self, id, name):
        self.id = id
        self.name = name

    @abstractmethod
    def run(self, task: str) -> str:
        pass