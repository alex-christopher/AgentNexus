from agentnexus.agents.developer_agent import DeveloperAgent

agent = DeveloperAgent(api_key="api_key", endpoint="http://dummy", model_name="gpt-3.5-turbo")

print("Agent name : ", agent.name)